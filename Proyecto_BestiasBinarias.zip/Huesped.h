#ifndef HUESPED_H_INCLUDED
#define HUESPED_H_INCLUDED
#include <iostream>
using namespace std;

class huesped{
    private:
        int id;
        int totalhuesped;
        string nombre;
        string correo;
        int dias;
        string fechaIn;
        string fechaSa;
        int habitacion;
        string comida;
        string limpieza;
        string objetosEx;
        string guarde;
        string transporte;
        string spa;
        string turismo;
        string fiesta;
        string tiendaRecu;
        int totalPago;

    public:
        void setId(const int&);
        void setTotalHuesped(const int&);
        void setDias(const int&);
        void setHabitacion(const int&);
        void setPagarCero(const int&);
        void setCostos(const int&);
        void setPagar(const int&);
        void setNombre(const string&);
        void setCorreo(const string&);
        void setFechaIn(const string&);
        void setFechaSa(const string&);
        void setComida(const string&);
        void setLimpieza(const string&);
        void setObjetosEx(const string&);
        void setGuarde(const string&);
        void setTransporte(const string&);
        void setSpa(const string&);
        void setTurismo(const string&);
        void setFiesta(const string&);
        void setTiendaRecu(const string&);

        int getId();
        int getTotalHuesped();
        int getDias();
        int getHabitacion();
        int getTotalPago();
        string getNombre();
        string getCorreo();
        string getFechaIn();
        string getFechaSa();
        string getComida();
        string getLimpieza();
        string getObjetosEx();
        string getGuarde();
        string getTransporte();
        string getSpa();
        string getTurismo();
        string getFiesta();
        string getTiendaRecu();

        string imprimir();

        huesped& operator = (const huesped&);
};

#endif // HUESPED_H_INCLUDED
