#ifndef TRABAJADOR_H_INCLUDED
#define TRABAJADOR_H_INCLUDED

#include <iostream>
#include "persona.h"

using namespace std;

class Trabajador{
    private:
        int numTra;
        string nombre;
        string area;
        string FechaIn;
        string FechaSa;
        int piso;

    public:
        void setNumTra(const int&);
        void setNombre(const string&);
        void setArea(const string&);
        void setFechaIn(const string&);
        void setFechaSa(const string&);
        void setPiso(const int&);

        int getNumTra();
        string getNombre();
        string getArea();
        string getFechaIn();
        string getFechaSa();
        int getPiso();

        string imprimir();

        Trabajador& operator =(const Trabajador&);
};

#endif // TRABAJADOR_H_INCLUDED
