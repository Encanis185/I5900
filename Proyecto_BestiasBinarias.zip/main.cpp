#include <iostream>
#include <clocale>
#include <windows.h>
#include "Huesped.h"
#include "Trabajador.h"
#include "Estacionamiento.h"
#include "List.h"
using namespace std;

bool verificarId(string opc){
	if(opc.length()==0)
        return false;
	for(int x=opc.length()-1;x>=0;x--){
	if(opc[x]<46 || opc[x]>57) return false;
	}
	return true;
}

int convertirId(string p){
	string opc=p;
	if(verificarId(opc)==true){
	int a=0;
	a=atoi(opc.c_str());
	return a;}
	else{
	return -1;}
}

int main()
{
    setlocale(LC_CTYPE,"Spanish");
    SetConsoleCP(1252);
    SetConsoleOutputCP(1252);
    List<huesped> li1;
    List<Trabajador> li2;
    List<string> li3;
    List<Estacinamiento> li4;
    huesped h;
    Trabajador t;
    Estacinamiento e;
    string opc, auxs, auxser;
    int swi,swi2,id=1,tr=1,est,total,auxn,auxn2,auxn3,auxn4;

    do{
    do{
            total=0;
            auxs="";
            h.setPagarCero(total);
            h.setComida(auxs);
            h.setLimpieza(auxs);
            h.setObjetosEx(auxs);
            h.setGuarde(auxs);
            h.setTransporte(auxs);
            h.setSpa(auxs);
            h.setTurismo(auxs);
            h.setFiesta(auxs);
            h.setTiendaRecu(auxs);
           system("cls");
    cout << "<<<<<<<<<<<<<<<<<<<<<<<<<   HOTEL BESTIAS NOCTURNAS   >>>>>>>>>>>>>>>>>>>>>>>>>" << endl <<endl;
    cout<<"1) Agregar Hu�sped\n2) Mostrar huespedes del hotel\n3) Trabajadores\n4) Tienda de recuerdos\n5) Quejas\n6) Estacionamiento"<<endl;
    cout<<"7) Pagar\n8) Eliminar Hu�sped\n9) Salir"<<endl<<endl;
    cout<<"Seleccione un opci�n: ";
    cin>>opc;
    system("cls");
    }while(convertirId(opc)==-1);
    swi=convertirId(opc);

        switch(swi){

            case 1: do{
                    do{
                        system("cls");
                    cout<<"\t\t<<<<<<<<< REGISTRO DEL HU�SPED >>>>>>>>>"<<endl<<endl;
                    cout<<"Su Id de hu�sped es: "<<id<<" *RECUERDELO YA QUE SERA SU IDENTIFICACI�N DE HU�SPED*"<<endl<<endl;
                    h.setId(id);
                    cout<<"Cu�ntos huespedes se hospedaran *M�XIMO 4 PERSONAS* : ";
                    cin>>auxs;
                    }while(convertirId(auxs)==-1);
                    auxn=convertirId(auxs);
                    }while(auxn>4 || auxn==0);
                    h.setTotalHuesped(auxn);

                    do{
                    do{
                    do{
                        system("cls");
                    cout<<"\t\t<<<<<<<<< REGISTRO DEL HU�SPED >>>>>>>>>"<<endl<<endl;
                    cout<<"Su Id de hu�sped es: "<<id<<" *RECUERDELO YA QUE SERA SU IDENTIFICACI�N DE HU�SPED*"<<endl<<endl;
                    cout<<"Cu�ntos huespedes se hospedaran *M�XIMO 4 PERSONAS* : "<<auxn;
                    cout<<"\n\nN�mero de habitaci�n *CONTAMOS DEL 1 AL 50* : ";
                    cin>>auxs;
                    }while(convertirId(auxs)==-1);
                    auxn2=convertirId(auxs);
                    }while(auxn2>50 || auxn2==0);
                    }while(li1.verificarHabita(auxn2)==false);

                    h.setHabitacion(auxn2);
                    do{
                    do{
                        system("cls");
                    cout<<"\t\t<<<<<<<<< REGISTRO DEL HU�SPED >>>>>>>>>"<<endl<<endl;
                    cout<<"Su Id de hu�sped es: "<<id<<" *RECUERDELO YA QUE SERA SU IDENTIFICACI�N DE HU�SPED*"<<endl<<endl;
                    cout<<"Cu�ntos huespedes se hospedaran *M�XIMO 4 PERSONAS* : "<<auxn;
                    cout<<"\n\nN�mero de habitaci�n *CONTAMOS DEL 1 AL 50* : "<<auxn2;
                    cout<<"\n\nD�as hospedado ($200 EL DIA) *M�XIMO 7 DIAS* : ";
                    cin>>auxs;
                    }while(convertirId(auxs)==-1);
                    auxn3=convertirId(auxs);
                    }while(auxn3>7 || auxn3==0);
                    total= 200*auxn3;
                    h.setCostos(total);
                    h.setDias(auxn3);

                    cout<<"\nNombre completo: ";
                    fflush(stdin);
                    getline(cin,auxs);
                    h.setNombre(auxs);
                    cout<<"\nCorreo electronico: ";
                    fflush(stdin);
                    getline(cin,auxs);
                    h.setCorreo(auxs);
                    cout<<"\nFecha de ingreso: ";
                    fflush(stdin);
                    getline(cin,auxs);
                    h.setFechaIn(auxs);
                    cout<<"\nFecha de Salida: ";
                    fflush(stdin);
                    getline(cin,auxs);
                    h.setFechaSa(auxs);
                    cout<<"\nDesea alg�n otro servicio   S/N : ";
                    fflush(stdin);
                    getline(cin,auxs);
                    if(auxs=="S" || auxs=="s"){
                        do{
                        do{
                                system("cls");
                        cout<<"\t\t<<<<<<<<< SERVICIOS EXTRA >>>>>>>>>"<<endl;
                        cout<<"Estos servicios extra estar�n disponibles por todos los d�as de su estancia."<<endl<<endl;
                        cout<<"1) Comidas\n2) Limpieza *GRATIS*\n3) Objetos extra\n4) Guarder�a $150\n5) Transporte\n6) Spa $250"<<endl;
                        cout<<"7) Turismo\n8) Party o evento $250\n9) Terminar registro"<<endl<<endl;
                        cout<<"Seleccione un opci�n: ";
                        cin>>opc;
                        system("cls");
                        }while(convertirId(opc)==-1);
                        swi2=convertirId(opc);

                        switch(swi2){

                            case 1: auxser="\n<<<<< COMIDAS >>>>>\n";
                                    do{
                                    do{
                                        system("cls");
                                    cout<<"\t\t<<<<<<<<< COMIDAS >>>>>>>>>"<<endl;
                                    cout<<"Estos servicios extra estar�n disponibles por todos los d�as de su estancia."<<endl<<endl;
                                    cout<<"1) Desayunos $250\n2) Comidas $350\n3) Cenas $200\n4) Bebidas $100\n5) Meriendas $150\n6) Regresar a Servicios"<<endl<<endl;
                                    cout<<"Seleccione un opci�n: ";
                                    cin>>opc;
                                    system("cls");
                                    }while(convertirId(opc)==-1);
                                    swi=convertirId(opc);

                                    switch(swi){

                                        case 1: total=250;
                                                do{
                                                system("cls");
                                                cout<<"Cu�ntas personas: ";
                                                cin>>auxn;
                                                }while(auxn>h.getTotalHuesped() || auxn==0);
                                                total= total*auxn;
                                                auxser+="Desayunos $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 2: total=350;
                                                do{
                                                system("cls");
                                                cout<<"Cu�ntas personas: ";
                                                cin>>auxn;
                                                }while(auxn>h.getTotalHuesped() || auxn==0);
                                                total= total*auxn;
                                                auxser+="Comidas $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 3: total=200;
                                                do{
                                                system("cls");
                                                cout<<"Cu�ntas personas: ";
                                                cin>>auxn;
                                                }while(auxn>h.getTotalHuesped() || auxn==0);
                                                total= total*auxn;
                                                auxser+="Cenas $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 4: total=100;
                                                do{
                                                system("cls");
                                                cout<<"Cu�ntas personas: ";
                                                cin>>auxn;
                                                }while(auxn>h.getTotalHuesped() || auxn==0);
                                                total= total*auxn;
                                                auxser+="Bebidas $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 5: total=150;
                                                do{
                                                system("cls");
                                                cout<<"Cu�ntas personas: ";
                                                cin>>auxn;
                                                }while(auxn>h.getTotalHuesped() || auxn==0);
                                                total= total*auxn;
                                                auxser+="Meriendas $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 6: h.setComida(auxser);
                                                break;
                                    }
                                    }while(swi!=6);
                                    break;

                            case 2: auxser="\n<<<<< LIMPIEZA >>>>>\n";
                                    cout<<"\t\t<<<<<<<<< LIMPIEZA >>>>>>>>>"<<endl;
                                    cout<<"Estos servicios extra estar�n disponibles por todos los d�as de su estancia."<<endl<<endl;
                                    cout<<"Horario en que se har� limpieza: ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                    auxser+="Horario en que se hara limpieza: " + auxs + "\n";
                                    cout<<"\nLimpieza en una parte en espec�fico: ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                    auxser+="Limpieza en una parte en espec�fico: " + auxs + "\n";
                                    h.setLimpieza(auxser);
                                    break;

                            case 3: auxser="\n<<<<< OBJETOS EXTRA >>>>>\n";
                                    do{
                                    do{
                                        system("cls");
                                    cout<<"\t\t<<<<<<<<< OBJETOS EXTRA >>>>>>>>>"<<endl;
                                    cout<<"Estos servicios extra estar�n disponibles por todos los d�as de su estancia."<<endl<<endl;
                                    cout<<"1) Toallas $100\n2) Sabanas $100\n3) Papel higienico $20\n4) Cosmeticos del ba�o $50\n5) Almohadas $50\n6) Regresar a Servicios"<<endl<<endl;
                                    cout<<"Seleccione un opci�n: ";
                                    cin>>opc;
                                    system("cls");
                                    }while(convertirId(opc)==-1);
                                    swi=convertirId(opc);

                                    switch(swi){

                                        case 1: total=100;
                                                system("cls");
                                                cout<<"Cu�ntos objetos: ";
                                                cin>>auxn;
                                                total= total*auxn;
                                                auxser+="Toallas $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 2: total=100;
                                                system("cls");
                                                cout<<"Cu�ntos objetos: ";
                                                cin>>auxn;
                                                total= total*auxn;
                                                auxser+="Sabanas $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 3: total=20;
                                                system("cls");
                                                cout<<"Cu�ntos objetos: ";
                                                cin>>auxn;
                                                total= total*auxn;
                                                auxser+="Papel higienico $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 4: total=50;
                                                system("cls");
                                                cout<<"Cu�ntos objetos: ";
                                                cin>>auxn;
                                                total= total*auxn;
                                                auxser+="Cosmeticos del ba�o $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 5: total=50;
                                                system("cls");
                                                cout<<"Cu�ntos objetos: ";
                                                cin>>auxn;
                                                total= total*auxn;
                                                auxser+="Almohadas $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 6: h.setObjetosEx(auxser);
                                                break;
                                    }
                                    }while(swi!=6);
                                    break;

                            case 4: total=150;
                                    auxser="\n<<<<< GUARDER�A >>>>>";
                                    do{
                                            system("cls");
                                    cout<<"\t\t<<<<<<<<< GUARDER�A >>>>>>>>>"<<endl;
                                    cout<<"Estos servicios extra estar�n disponibles por todos los d�as de su estancia."<<endl<<endl;
                                    cout<<"Cu�ntos ni�os va a ingresar: ";
                                    cin>>auxn;
                                    }while(auxn>=h.getTotalHuesped() || auxn==0);
                                    total= total*auxn;
                                    h.setCostos(total);
                                    for(int i=0;i<auxn;i++){
                                        system("cls");
                                        cout<<"Nombre del ni�o/a: ";
                                        fflush(stdin);
                                        getline(cin,auxs);
                                        auxser+= "\n\t$150\nNombre del ni�o/a: " + auxs;
                                        cout<<"\nEdad: ";
                                        fflush(stdin);
                                        getline(cin,auxs);
                                        auxser+= "\nEdad: " + auxs;
                                        cout<<"\nTutor: ";
                                        fflush(stdin);
                                        getline(cin,auxs);
                                        auxser+= "\nTutor: " + auxs;
                                        cout<<"\nHora de entrada: ";
                                        fflush(stdin);
                                        getline(cin,auxs);
                                        auxser+= "\nHora de entrada: " + auxs;
                                        cout<<"\nHora de Salida: ";
                                        fflush(stdin);
                                        getline(cin,auxs);
                                        auxser+= "\nHora de salida: " + auxs + "\n";
                                    }
                                    h.setGuarde(auxser);
                                    break;

                            case 5: auxser="\n<<<<< TRANSPORTE >>>>>\n";
                                    do{
                                    do{
                                        system("cls");
                                        cout<<"\t\t<<<<<<<<< TRANSPORTE >>>>>>>>>"<<endl;
                                        cout<<"Estos servicios extra estar�n disponibles por todos los d�as de su estancia."<<endl<<endl;
                                        cout<<"Seleccione un medio de transporte que lo llevara a donde usted quiera."<<endl<<endl;
                                        cout<<"1)Bus $200\n2)Taxi $300\n3)Uber $450\n4)Limo $700"<<endl<<endl;
                                        cout<<"Seleccione un opci�n: ";
                                        cin>>auxs;
                                        cout<<endl<<endl;
                                        system("cls");
                                    }while(convertirId(auxs)==-1);
                                    auxn=convertirId(auxs);
                                    }while(auxn>4 || auxn==0);
                                    if(auxn==1){
                                        auxser+= "Bus $200\n";
                                        total=200;
                                        h.setCostos(total);
                                        h.setTransporte(auxser);
                                    }
                                    if(auxn==2){
                                        auxser+= "Taxi $300\n";
                                        total=300;
                                        h.setCostos(total);
                                        h.setTransporte(auxser);
                                    }
                                    if(auxn==3){
                                        auxser+= "Uber $450\n";
                                        total=450;
                                        h.setCostos(total);
                                        h.setTransporte(auxser);
                }
                                    if(auxn==4){
                                        auxser+= "Limo $700\n";
                                        total=700;
                                        h.setCostos(total);
                                        h.setTransporte(auxser);
                                    }
                                    system("pause");
                                    break;

                            case 6: total=250;
                                    auxser="\n<<<<< SPA >>>>>\n";
                                    do{
                                            system("cls");
                                    cout<<"\t\t<<<<<<<<< SPA >>>>>>>>>"<<endl;
                                    cout<<"Estos servicios extra estar�n disponibles por todos los d�as de su estancia."<<endl<<endl;
                                    cout<<"Cu�ntas personas ingresaran al Spa: ";
                                    cin>>auxn;
                                    }while(auxn>h.getTotalHuesped() || auxn==0);
                                    total= total*auxn;
                                    h.setCostos(total);
                                        auxser+= "Personas que ingresar�n: " + to_string(auxn) + "\n";
                                    cout<<"\nD�as: ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                        auxser+= "D�as: " + auxs + "\n";
                                    cout<<"\nHora de ingreso: ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                        auxser+= "Hora de ingreso: " + auxs + "\n";
                                    cout<<"\nHora de salida: ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                        auxser+= "Hora de salida: " + auxs + "\n";
                                        auxser+= "Total: $" + to_string(total) + "\n";
                                    h.setSpa(auxser);
                                    break;

                            case 7: auxser="\n<<<<< TURISMO >>>>>\n";
                                    do{
                                    do{
                                        system("cls");
                                    cout<<"\t\t<<<<<<<<< TURISMO >>>>>>>>>"<<endl;
                                    cout<<"Estos servicios extra estar�n disponibles por todos los d�as de su estancia."<<endl<<endl;
                                    cout<<"1) Islas Mar�a $300\n2) Playa del Carmen $250\n3) Centro de la ciudad $100\n4) Paisaje tur�stico en monta�a $350\n5) Regresar a Servicios"<<endl<<endl;
                                    cout<<"Seleccione un opci�n: ";
                                    cin>>opc;
                                    system("cls");
                                    }while(convertirId(opc)==-1);
                                    swi=convertirId(opc);

                                    switch(swi){

                                        case 1: total=300;
                                                do{
                                                system("cls");
                                                cout<<"Cu�ntas personas: ";
                                                cin>>auxn;
                                                }while(auxn>h.getTotalHuesped() || auxn==0);
                                                total= total*auxn;
                                                auxser+="Islas Mar�a $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 2: total=250;
                                                do{
                                                system("cls");
                                                cout<<"Cu�ntas personas: ";
                                                cin>>auxn;
                                                }while(auxn>h.getTotalHuesped() || auxn==0);
                                                total= total*auxn;
                                                auxser+="Playa del Carmen $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 3: total=100;
                                                do{
                                                system("cls");
                                                cout<<"Cu�ntas personas: ";
                                                cin>>auxn;
                                                }while(auxn>h.getTotalHuesped() || auxn==0);
                                                total= total*auxn;
                                                auxser+="Centro de la ciudad $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 4: total=350;
                                                do{
                                                system("cls");
                                                cout<<"Cu�ntas personas: ";
                                                cin>>auxn;
                                                }while(auxn>h.getTotalHuesped() || auxn==0);
                                                total= total*auxn;
                                                auxser+="Paisaje tur�stico en monta�a $" + to_string(total) + "\n";
                                                h.setCostos(total);
                                                break;

                                        case 5: h.setTurismo(auxser);
                                                break;
                                    }
                                    }while(swi!=5);
                                    break;

                            case 8: auxser="\n<<<<< PARTY >>>>>\n";
                                    total=250;
                                    auxser+= "Fiesta privada $250\n";
                            system("cls");
                                    cout<<"\t\t<<<<<<<<< PARTY >>>>>>>>>"<<endl;
                                    cout<<"Estos servicios extra estar�n disponibles por todos los d�as de su estancia."<<endl<<endl;
                                    cout<<"Escriba S si desea agregarlo a su fiesta o una N si no lo desea."<<endl<<endl;
                                    cout<<"Comida $300 ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                    if(auxs=="S" || auxs=="s"){
                                        auxser+= "Comida $300\n";
                                        total+=300;
                                    }
                                    cout<<"Dj $700 ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                    if(auxs=="S" || auxs=="s"){
                                        auxser+= "Dj $700\n";
                                        total+=700;
                                    }
                                    cout<<"Banda $650 ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                    if(auxs=="S" || auxs=="s"){
                                        auxser+= "Banda $650\n";
                                        total+=650;
                                    }
                                    cout<<"Meseros $300 ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                    if(auxs=="S" || auxs=="s"){
                                        auxser+= "Meseros $300\n";
                                        total+=300;
                                    }
                                    cout<<"Alberca $800 ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                    if(auxs=="S" || auxs=="s"){
                                        auxser+= "Alberca $800\n";
                                        total+=800;
                                    }
                                    cout<<"Seguridad $700 ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                    if(auxs=="S" || auxs=="s"){
                                        auxser+= "Seguridad $700\n";
                                        total+=700;
                                    }
                                    cout<<"Estacionamiento $500 ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                    if(auxs=="S" || auxs=="s"){
                                        auxser+= "Estacionamiento $500\n";
                                        total+=500;
                                    }
                                    cout<<"Pastel $250 ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                    if(auxs=="S" || auxs=="s"){
                                        auxser+= "Pastel $250\n";
                                        total+=250;
                                    }
                                    cout<<"Bebidas Alcoh�licas $900 ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                    if(auxs=="S" || auxs=="s"){
                                        auxser+= "Bebidad Alcoh�licas $900\n";
                                        total+=900;
                                    }
                                    cout<<"Centros de mesa $500 ";
                                    fflush(stdin);
                                    getline(cin,auxs);
                                    if(auxs=="S" || auxs=="s"){
                                        auxser+= "Centros de mesas $500\n";
                                        total+=500;
                                    }
                                    h.setFiesta(auxser);
                                    h.setCostos(total);
                                    system("pause");
                                    break;

                        }
                        }while(swi2!=9);
                    }
                    cout<<"\n\t\t<<<<<<<<REGISTRO COMPLETADO>>>>>>>>"<<endl<<endl;
                    li1.insertData(li1.getLastPos(),h);
                    id++;
                    system("pause");
                    break;

            case 2: do{
                        system("cls");
                    cout<<"<<<<<<<<<<<<<<<<<<<<<<<<<   HUESPEDES   >>>>>>>>>>>>>>>>>>>>>>>>>"<<endl<<endl;
                    cout<<"1) Mostrar de uno por uno\n2) Mostrar por id\n3) Regresar al men�"<<endl<<endl;
                    cout<<"Seleccione un opci�n: ";
                    cin>>opc;
                    system("cls");
                    }while(convertirId(opc)==-1);
                    swi=convertirId(opc);

                    switch(swi){

                        case 1: if(li1.isEmpty()){//cambias el li1 a li2 o li3 o li4 dependiendo si es huesped, coche, etc.
                               cout<<"No hay nada registrado."<<endl<<endl;
                               system("pause");
                               }
                               else{
                                int b(1),aa(0);
                                char to;
                                string contenido;
                                do{
                                system("cls");
                                contenido=li1.mostrar(b);  //cambias el li1 a li2 o li3 o li4 dependiendo si es huesped, coche, etc.
                                cout<<contenido;
                                cout<<"Digite 'a' para anterior."<<endl<<"Digite 'd' para siguiente."<<endl<<"Digite 's' para salir."<<endl<<endl;
                               to=getch();
                                switch(to){

                                case 'a': case 'A':
                                          b--;
                                          if(b<1){
                                            b=li1.aventura();}
                                          system("cls");
                                          break;

                                case 'd': case 'D':
                                          b++;
                                          if(b>li1.aventura()){
                                            b=1;}
                                          system("cls");
                                          break;

                                case 's': case 'S': aa=1;break;
                                }
                                }while(aa!=1);
                               }
                           break;

                        case 2: do{
                                cout<<"Digite su Id: ";
                                cin>>opc;
                                system("cls");
                                }while(convertirId(opc)==-1);
                                auxn2=convertirId(opc);
                                if(auxn2>=id || auxn2==0){
                                    cout<<"Ese Id no es v�lido."<<endl<<endl;
                                    system("pause");
                                }
                                else{
                                    cout<<li1.mostrarHuespedId(auxn2)<<endl<<endl;
                                    system("pause");
                                }
                                break;
                    }
                    break;

            case 3: do{
                    do{
                    system("cls");
                    cout << "<<<<<<<<<<<<<<<<<<<<<<<<<   TRABAJADORES   >>>>>>>>>>>>>>>>>>>>>>>>>" << endl <<endl;
                    cout<<"1) Agregar Trabajador\n2) Mostrar Trabajadores del hotel\n3) Regresar al men�"<<endl<<endl;
                    cout<<"Seleccione un opci�n: ";
                    cin>>opc;
                    system("cls");
                    }while(convertirId(opc)==-1);
                    swi=convertirId(opc);

                    switch(swi){

                        case 1: do{
                                do{
                                        system("cls");
                                cout<<"\t\t<<<<<<<<< REGISTRO DEL TRABAJADOR >>>>>>>>>"<<endl<<endl;
                                cout<<"No. de trabajador: "<<tr<<endl<<endl;
                                cout<<"Piso asignado *DEL PISO 1 AL 11* : ";
                                cin>>auxs;
                                }while(convertirId(auxs)==-1);
                                auxn=convertirId(auxs);
                                }while(auxn>11 || auxn==0);
                                t.setPiso(auxn);
                                t.setNumTra(tr);
                                cout<<"\nNombre completo: ";
                                fflush(stdin);
                                getline(cin,auxs);
                                t.setNombre(auxs);
                                cout<<"\n�rea de trabajo: ";
                                fflush(stdin);
                                getline(cin,auxs);
                                t.setArea(auxs);
                                cout<<"\nFecha de Ingreso: ";
                                fflush(stdin);
                                getline(cin,auxs);
                                t.setFechaIn(auxs);
                                cout<<"\nFecha de Salida: ";
                                fflush(stdin);
                                getline(cin,auxs);
                                t.setFechaSa(auxs);
                                li2.insertData(li2.getLastPos(),t);
                                system("cls");
                                cout<<"\n\t\t<<<<<<<<TRABAJADOR REGISTRADO>>>>>>>>"<<endl<<endl;
                                tr++;
                                system("pause");
                                break;

                        case 2: if(li2.isEmpty()){//cambias el li1 a li2 o li3 o li4 dependiendo si es huesped, coche, etc.
                               cout<<"No hay nada registrado."<<endl<<endl;
                               system("pause");
                               }
                               else{
                                int b(1),aa(0);
                                char to;
                                string contenido;
                                do{
                                system("cls");
                                contenido=li2.mostrar(b);  //cambias el li1 a li2 o li3 o li4 dependiendo si es huesped, coche, etc.
                                cout<<contenido;
                                cout<<"Digite 'a' para anterior."<<endl<<"Digite 'd' para siguiente."<<endl<<"Digite 's' para salir."<<endl<<endl;
                               to=getch();
                                switch(to){

                                case 'a': case 'A':
                                          b--;
                                          if(b<1){
                                            b=li2.aventura();}
                                          system("cls");
                                          break;

                                case 'd': case 'D':
                                          b++;
                                          if(b>li2.aventura()){
                                            b=1;}
                                          system("cls");
                                          break;

                                case 's': case 'S': aa=1;break;
                                }
                                }while(aa!=1);
                               }
                           break;

                    }
                    }while(swi!=3);

                    break;

            case 4: do{
                    cout<<"Digite su Id: ";
                    cin>>opc;
                    system("cls");
                    }while(convertirId(opc)==-1);
                    auxn2=convertirId(opc);
                    if(auxn2>=id || auxn2==0){
                        cout<<"Ese Id no es v�lido."<<endl<<endl;
                        system("pause");
                    }else if(li1.verifiId(auxn2)==false){
                        cout<<"Ese Id no se encuentra ya."<<endl<<endl;
                        system("pause");
                    }else{
                        h=li1.retornaH(auxn2);
                        auxser="";
                        do{
                do{
                system("cls");
                cout<<"\t\t<<<<<<<<< TIENDA DE RECUERDOS >>>>>>>>>"<<endl<<endl;
                cout<<"1) Camisetas $200\n2) Tazas $100\n3) Llaveros $50\n4) Plumas $20\n5) Peluches $150\n6) Juguetes $100"<<endl;
                cout<<"7) Gorras $100\n8) Pulseras $100\n9) Collares $150\n10) Regresar al men�"<<endl<<endl;
                cout<<"Seleccione un opci�n: ";
                    cin>>opc;
                    system("cls");
                }while(convertirId(opc)==-1);
                swi=convertirId(opc);

                switch(swi){

                    case 1: total=200;
                            system("cls");
                            cout<<"Cu�ntas camisas: ";
                            cin>>auxn;
                            total= total*auxn;
                            auxser+= to_string(auxn) + " Camisas $" + to_string(total) + "\n";
                            h.setCostos(total);
                            break;

                    case 2: total=100;
                            system("cls");
                            cout<<"Cu�ntas tazas: ";
                            cin>>auxn;
                            total= total*auxn;
                            auxser+= to_string(auxn) + " Tazas $" + to_string(total) + "\n";
                            h.setCostos(total);
                            break;

                    case 3: total=50;
                            system("cls");
                            cout<<"Cu�ntos llaveros: ";
                            cin>>auxn;
                            total= total*auxn;
                            auxser+= to_string(auxn) + " Llaveros $" + to_string(total) + "\n";
                            h.setCostos(total);
                            break;

                    case 4: total=20;
                            system("cls");
                            cout<<"Cu�ntas plumas: ";
                            cin>>auxn;
                            total= total*auxn;
                            auxser+= to_string(auxn) + " Plumas $" + to_string(total) + "\n";
                            h.setCostos(total);
                            break;

                    case 5: total=150;
                            system("cls");
                            cout<<"Cu�ntos peluches: ";
                            cin>>auxn;
                            total= total*auxn;
                            auxser+= to_string(auxn) + " Peluches $" + to_string(total) + "\n";
                            h.setCostos(total);
                            break;

                    case 6: total=100;
                            system("cls");
                            cout<<"Cu�ntos juguetes: ";
                            cin>>auxn;
                            total= total*auxn;
                            auxser+= to_string(auxn) + " Juguetes $" + to_string(total) + "\n";
                            h.setCostos(total);
                            break;

                    case 7: total=100;
                            system("cls");
                            cout<<"Cu�ntas gorras: ";
                            cin>>auxn;
                            total= total*auxn;
                            auxser+= to_string(auxn) + " Gorras $" + to_string(total) + "\n";
                            h.setCostos(total);
                            break;

                    case 8: total=100;
                            system("cls");
                            cout<<"Cu�ntas pulseras: ";
                            cin>>auxn;
                            total= total*auxn;
                            auxser+= to_string(auxn) + " Pulseras $" + to_string(total) + "\n";
                            h.setCostos(total);
                            break;

                    case 9: total=150;
                            system("cls");
                            cout<<"Cu�ntos collares: ";
                            cin>>auxn;
                            total= total*auxn;
                            auxser+= to_string(auxn) + " Collares $" + to_string(total) + "\n";
                            h.setCostos(total);
                            break;

                    case 10: h.setTiendaRecu(auxser);
                }
                }while(swi!=10);
                        li1.Intercambiar(auxn2,h);
                        system("pause");
                    }
                    break;

            case 5: do{
                    do{
                    system("cls");
                    cout << "<<<<<<<<<<<<<<<<<<<<<<<<<   QUEJAS   >>>>>>>>>>>>>>>>>>>>>>>>>" << endl <<endl;
                    cout<<"1) Agregar una queja\n2) Mostrar las quejas\n3) Regresar al men�"<<endl<<endl;
                    cout<<"Seleccione un opci�n: ";
                    cin>>opc;
                    system("cls");
                    }while(convertirId(opc)==-1);
                    swi=convertirId(opc);

                    switch(swi){

                        case 1: cout<<"\t\t<<<<<<<<< REGISTRO DE QUEJAS >>>>>>>>>"<<endl<<endl;
                                cout<<"Escriba la queja que tiene sobre su estancia en nuestro hotel: "<<endl;
                                fflush(stdin);
                                getline(cin,auxs);
                                li3.insertData(li3.getLastPos(),auxs);
                                cout<<"\n<<<<QUEJA GUARDADA, LAMENTAMOS MUCHO LA SITUACI�N>>>>"<<endl<<endl;
                                system("pause");
                                break;

                        case 2:if(li3.isEmpty()){//cambias el li1 a li2 o li3 o li4 dependiendo si es huesped, coche, etc.
                               cout<<"No hay nada registrado."<<endl<<endl;
                               system("pause");
                               }
                               else{
                                int b(1),aa(0);
                                char to;
                                string contenido;
                                do{
                                system("cls");
                                contenido=li3.mostrarQueja(b);  //cambias el li1 a li2 o li3 o li4 dependiendo si es huesped, coche, etc.
                                cout<<contenido;
                                cout<<"Digite 'a' para anterior."<<endl<<"Digite 'd' para siguiente."<<endl<<"Digite 's' para salir."<<endl<<endl;
                               to=getch();
                                switch(to){

                                case 'a': case 'A':
                                          b--;
                                          if(b<1){
                                            b=li3.aventura();}
                                          system("cls");
                                          break;

                                case 'd': case 'D':
                                          b++;
                                          if(b>li3.aventura()){
                                            b=1;}
                                          system("cls");
                                          break;

                                case 's': case 'S': aa=1;break;
                                }
                                }while(aa!=1);
                               }
                    }
                    }while(swi!=3);
                    break;

            case 6: do{
                    do{
                    system("cls");
                    cout << "<<<<<<<<<<<<<<<<<<<<<<<<<   ESTACIONAMIENTO   >>>>>>>>>>>>>>>>>>>>>>>>>" << endl <<endl;
                    cout<<"1) Agregar coche\n2) Mostrar coches\n3) Eliminar coche\n4) Regresar al men�"<<endl<<endl;
                    cout<<"Seleccione un opci�n: ";
                    cin>>opc;
                    system("cls");
                    }while(convertirId(opc)==-1);
                    swi=convertirId(opc);

                    switch(swi){

                        case 1: do{
                                do{
                                do{
                                system("cls");
                                cout<<"\t\t<<<<<<<<< REGISTRO DEL COCHE >>>>>>>>>"<<endl<<endl;
                                cout<<"No. de estacionamiento *SOLO TENEMOS DEL 1-5O* : ";
                                cin>>opc;
                                }while(convertirId(opc)==-1);
                                est=convertirId(opc);
                                }while(est>50 || est==0);
                                }while(li4.verifiEst(est)==false);
                                cout<<"\nPlacas del coche: ";
                                cin>>auxs;
                                e.setPlaca(auxs);
                                e.setId(est);
                                cout<<"\nModelo del coche: ";
                                fflush(stdin);
                                getline(cin,auxs);
                                e.setModeloAuto(auxs);
                                cout<<"\nHora de Ingreso: ";
                                fflush(stdin);
                                getline(cin,auxs);
                                e.setHoraEntrada(auxs);
                                cout<<"\nHora de Salida: ";
                                fflush(stdin);
                                getline(cin,auxs);
                                e.setHoraSalida(auxs);
                                li4.insertData(li4.getLastPos(),e);
                                system("cls");
                                cout<<"\n\t\t<<<<<<<<COCHE REGISTRADO>>>>>>>>"<<endl<<endl;
                                system("pause");
                                break;

                        case 2: if(li4.isEmpty()){//cambias el li1 a li2 o li3 o li4 dependiendo si es huesped, coche, etc.
                               cout<<"No hay nada registrado."<<endl<<endl;
                               system("pause");
                               }
                               else{
                                int b(1),aa(0);
                                char to;
                                string contenido;
                                do{
                                system("cls");
                                contenido=li4.mostrar(b);  //cambias el li1 a li2 o li3 o li4 dependiendo si es huesped, coche, etc.
                                cout<<contenido;
                                cout<<"Digite 'a' para anterior."<<endl<<"Digite 'd' para siguiente."<<endl<<"Digite 's' para salir."<<endl<<endl;
                               to=getch();
                                switch(to){

                                case 'a': case 'A':
                                          b--;
                                          if(b<1){
                                            b=li4.aventura();}
                                          system("cls");
                                          break;

                                case 'd': case 'D':
                                          b++;
                                          if(b>li4.aventura()){
                                            b=1;}
                                          system("cls");
                                          break;

                                case 's': case 'S': aa=1;break;
                                }
                                }while(aa!=1);
                               }
                           break;

                        case 3: do{
                                cout<<"Digite el No. de estacionamiento del coche a eliminar: ";
                                cin>>opc;
                                system("cls");
                                }while(convertirId(opc)==-1);
                                auxn2=convertirId(opc);
                                if(auxn2>50 || auxn2==0){
                                    cout<<"Ese No. de estacionamiento no es v�lido."<<endl<<endl;
                                    system("pause");
                                }else if(li4.verifiEst(auxn2)==true){
                                    cout<<"Ese No. de estacionamiento no se encuentra ocupado."<<endl<<endl;
                                    system("pause");
                                }
                                else{
                                        li4.deleteData(li4.findData(auxn2));
                                        cout<<"\n\n\t\t<<<<<<< COCHE ELIMINADO >>>>>>>"<<endl<<endl;
                                        system("pause");
                                }
                                break;
                    }
                    }while(swi!=4);

                    break;

            case 7: do{
                    cout<<"Digite su Id: ";
                    cin>>opc;
                    system("cls");
                    }while(convertirId(opc)==-1);
                    auxn2=convertirId(opc);
                    if(auxn2>=id || auxn2==0){
                        cout<<"Ese Id no es v�lido."<<endl<<endl;
                        system("pause");
                    }else if(li1.verifiId(auxn2)==false){
                        cout<<"Ese Id no se encuentra ya."<<endl<<endl;
                        system("pause");
                    }else{
                        h=li1.retornaH(auxn2);
                        if(h.getTotalPago()==0){
                            cout<<h.imprimir()<<endl<<endl;
                            cout<<"\t\t<<<<< LA CUENTA ESTA PAGADA >>>>>"<<endl<<endl;
                        }
                        else{
                            cout<<h.imprimir()<<endl;
                            auxn3=h.getTotalPago()*.16;
                            cout<<"Iva: $"<<to_string(auxn3)<<endl;
                            h.setCostos(auxn3);
                            cout<<"Total a pagar: $"<<h.getTotalPago()<<endl<<endl;
                            cout<<"Ingrese su pago: $";
                            cin>>auxn;
                            if(auxn==h.getTotalPago()){
                                h.setPagar(h.getTotalPago());
                                cout<<"\n\n\t\t<<<<< SU DEUDA ESTA SALDADA >>>>>"<<endl<<endl;
                            }else if(auxn>h.getTotalPago()){
                                auxn4= auxn-h.getTotalPago();
                                h.setPagar(h.getTotalPago());
                                cout<<"\n\nSu cambio es de: $"<<to_string(auxn4)<<endl<<endl;
                                cout<<"\t\t<<<<< SU DEUDA ESTA SALDADA >>>>>"<<endl<<endl;
                            }else if(auxn<h.getTotalPago()){
                                h.setPagar(auxn);
                                cout<<"\n\nLe falta por pagar: $"<<to_string(h.getTotalPago())<<endl;
                                cout<<"Se le volver� a cobrar el IVA de su nuevo 'Costos totales' cuando vuelva a querer pagar la deuda."<<endl<<endl;
                                cout<<"\t\t<<<<< LO LAMENTAMOS >>>>>"<<endl<<endl;
                            }
                            li1.Intercambiar(auxn2,h);
                        }
                        system("pause");
                    }
                    break;

            case 8: do{
                    cout<<"Digite el Id del hu�sped a eliminar: ";
                    cin>>opc;
                    system("cls");
                    }while(convertirId(opc)==-1);
                    auxn2=convertirId(opc);
                    if(auxn2>=id || auxn2==0){
                        cout<<"Ese Id no es v�lido."<<endl<<endl;
                        system("pause");
                    }else if(li1.verifiId(auxn2)==false){
                        cout<<"Ese Id no se encuentra ya."<<endl<<endl;
                        system("pause");
                    }
                    else{
                            li1.deleteData(li1.findData(auxn2));
                            cout<<"\n\n\t\t<<<<<<< HU�SPED ELIMINADO >>>>>>>"<<endl<<endl;
                            system("pause");
                    }
                    break;


            case 9: cout<<"Le agradecemos su estancia en nuestro Hotel Bestias Nocturnas, esperemos hayan tenido una buena estancia.\n\n\t\t<<<<<< REGRESEN PRONTO >>>>>>"<<endl;
                    break;

            default: cout<<"Esa no es una opci�n valida de nuestro men�."<<endl<<endl;
                     system("pause");
                     break;
        }
    }while(swi!=9);
    return 0;
}
