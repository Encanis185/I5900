#include "Huesped.h"

void huesped::setId(const int& aux)
{
    id=aux;
}

void huesped::setTotalHuesped(const int& aux)
{
    totalhuesped=aux;
}

void huesped::setDias(const int& aux)
{
    dias=aux;
}

void huesped::setHabitacion(const int& aux)
{
    habitacion=aux;
}

void huesped::setCostos(const int& aux)
{
    totalPago+=aux;
}

void huesped::setPagar(const int& aux)
{
    totalPago-=aux;
}

void huesped::setPagarCero(const int& aux)
{
    totalPago= totalPago*aux;
}

void huesped::setNombre(const string& aux)
{
    nombre=aux;
}

void huesped::setCorreo(const string& aux)
{
    correo=aux;
}

void huesped::setFechaIn(const string& aux)
{
    fechaIn=aux;
}

void huesped::setFechaSa(const string& aux)
{
    fechaSa=aux;
}

void huesped::setComida(const string& aux)
{
    comida=aux;
}

void huesped::setLimpieza(const string& aux)
{
    limpieza=aux;
}

void huesped::setObjetosEx(const string& aux)
{
    objetosEx=aux;
}

void huesped::setGuarde(const string& aux)
{
    guarde=aux;
}

void huesped::setTransporte(const string& aux)
{
    transporte=aux;
}

void huesped::setSpa(const string& aux)
{
    spa=aux;
}

void huesped::setTurismo(const string& aux)
{
    turismo=aux;
}

void huesped::setFiesta(const string& aux)
{
    fiesta=aux;
}

void huesped::setTiendaRecu(const string& aux)
{
    tiendaRecu=aux;
}

int huesped::getId()
{
    return id;
}

int huesped::getTotalHuesped()
{
    return totalhuesped;
}

int huesped::getDias()
{
    return dias;
}

int huesped::getHabitacion()
{
    return habitacion;
}

int huesped::getTotalPago()
{
    return totalPago;
}

string huesped::getNombre()
{
    return nombre;
}

string huesped::getCorreo()
{
    return correo;
}

string huesped::getFechaIn()
{
    return fechaIn;
}

string huesped::getFechaSa()
{
    return fechaSa;
}

string huesped::getComida()
{
    return comida;
}

string huesped::getLimpieza()
{
    return limpieza;
}

string huesped::getObjetosEx()
{
    return objetosEx;
}

string huesped::getGuarde()
{
    return guarde;
}

string huesped::getTransporte()
{
    return transporte;
}

string huesped::getSpa()
{
    return spa;
}

string huesped::getTurismo()
{
    return turismo;
}

string huesped::getFiesta()
{
    return fiesta;
}

string huesped::getTiendaRecu()
{
    return tiendaRecu;
}

string huesped::imprimir()
{
    string resultado;
    int dia=200;

    resultado+="\n\t\t<<<<<<<<< INFORMACI�N DEL HUESPED >>>>>>>>>\n";
    resultado+="\nId: ";
    resultado+=to_string(id);
    resultado+="\nHuespedes totales: ";
    resultado+=to_string(totalhuesped);
    resultado+="\nNombre: ";
    resultado+=nombre;
    resultado+="\nCorreo: ";
    resultado+=correo;
    dia= dia*dias;
    resultado+="\nD�as hospedado: ";
    resultado+=to_string(dias);
    resultado+=" $" + to_string(dia);
    resultado+="\nFecha de ingreso: ";
    resultado+=fechaIn;
    resultado+="\nFecha de salida: ";
    resultado+=fechaSa;
    resultado+="\nNo. de habitaci�n: ";
    resultado+=to_string(habitacion);
    resultado+="\n\n\t\t<<<<<<<<<   SERVICIOS EXTRA   >>>>>>>>\n";
    resultado+=comida;
    resultado+=limpieza;
    resultado+=objetosEx;
    resultado+=guarde;
    resultado+=transporte;
    resultado+=spa;
    resultado+=turismo;
    resultado+=fiesta;
    resultado+="\n\t\t<<<<<<<<< TIENDA DE RECUERDOS >>>>>>>>>\n";
    resultado+=tiendaRecu;
    resultado+="\nCostos totales: $";
    resultado+=to_string(totalPago);

    return resultado;
}

huesped& huesped::operator=(const huesped& h)
{
    id = h.id;
    nombre = h.nombre;
    dias = h.dias;
    fechaIn = h.fechaIn;
    fechaSa = h.fechaSa;
    habitacion = h.habitacion;
    comida = h.comida;
    limpieza = h.limpieza;
    objetosEx = h.objetosEx;
    guarde = h.guarde;
    transporte = h.transporte;
    spa = h.spa;
    turismo = h.turismo;
    fiesta = h.fiesta;
    tiendaRecu = h.tiendaRecu;
    totalPago = h.totalPago;

    return * this;
}
