#include "Estacionamiento.h"

using namespace std;

void Estacinamiento::setHoraEntrada(const string& entrada){
    HoraEntrada = entrada;
}

void Estacinamiento::setHoraSalida(const string& salida){
    HoraSalida = salida;
}

void Estacinamiento::setModeloAuto(const string& modelo){
    ModeloAuto = modelo;
}

void Estacinamiento::setPlaca(const string& placa){
    Placa = placa;
}

void Estacinamiento::setId(const int& num){
    NoEstacionamiento = num;
}

string Estacinamiento::getHoraEntrada() {
    return HoraEntrada;
}

string Estacinamiento::getHoraSalida() {
    return HoraSalida;
}

string Estacinamiento::getModeloAuto() {
    return ModeloAuto;
}

string Estacinamiento::getPlaca() {
    return Placa;
}

int Estacinamiento::getId() {
    return NoEstacionamiento;
}

string Estacinamiento::imprimir(){

 string e;

 e+="\n\t\t<<<<<<<<< INFORMACI�N DEL COCHE >>>>>>>>>\n";
 e+="\nNo. de estacionamiento: ";
 e+=to_string(NoEstacionamiento);
 e+="\nPlaca: ";
 e+=Placa;
 e+="\nModelo del coche: ";
 e+=ModeloAuto;
 e+="\nHora de ingreso: ";
 e+=HoraEntrada;
 e+="\nHora de salida: ";
 e+=HoraSalida;

 return e;

}
Estacinamiento& Estacinamiento:: operator=(const Estacinamiento& est){
     HoraEntrada=est.HoraEntrada;
     HoraSalida=est.HoraSalida;
     ModeloAuto=est.ModeloAuto;
     Placa=est.Placa;
     NoEstacionamiento=est.NoEstacionamiento;
     return * this;
     }
