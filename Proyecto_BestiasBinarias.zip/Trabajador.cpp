#include "Trabajador.h"

using namespace std;

void Trabajador::setNumTra(const int& aux)
{
    numTra=aux;
}

void Trabajador::setNombre(const string& tra)
{
    nombre=tra;
}

void Trabajador::setArea(const string& a)
{
    area=a;
}

void Trabajador::setFechaIn(const string& i)
{
   FechaIn=i;
}

void Trabajador::setFechaSa(const string& s)
{
   FechaSa= s;
}
void Trabajador::setPiso(const int& pi)
{
   piso=pi;
}

int Trabajador::getNumTra()
{
   return numTra;
}

string Trabajador::getNombre()
{
   return nombre;
}

string Trabajador::getArea()
{
   return area;
}

string Trabajador::getFechaIn()
{
   return FechaIn;
}

string Trabajador::getFechaSa()
{
    return FechaSa;
}

int Trabajador::getPiso()
{
    return piso;
}

string Trabajador::imprimir(){

 string t;

 t+="\n\t\t<<<<<<<<< INFORMACI�N DEL TRABAJADOR >>>>>>>>>\n";
 t+="\nNo. de trabajador: ";
 t+=to_string(numTra);
 t+="\nNombre: ";
 t+=nombre;
 t+="\n�rea de trabajo: ";
 t+=area;
 t+="\nFecha de ingreso: ";
 t+=FechaIn;
 t+="\nFecha de salida: ";
 t+=FechaSa;
 t+="\nPiso de trabajo: Piso ";
 t+=to_string(piso);

 return t;

}
Trabajador& Trabajador:: operator=(const Trabajador& cli){
     nombre=cli.nombre;
     area=cli.area;
     FechaIn=cli.FechaIn;
     FechaSa=cli.FechaSa;
     piso=cli.piso;
     return * this;
     }
