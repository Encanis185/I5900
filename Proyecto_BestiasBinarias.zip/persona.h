#ifndef PERSONA_H_INCLUDED
#define PERSONA_H_INCLUDED

#include <iostream>

using namespace std;

class Persona
{
private:
    string Nombres;
    string Apellido;
public:
    Persona();
    string getNombres();
    string getApellido();

    void setNombres(const string&);
    void setApellido(const string&);

    string toString();
};

#endif // PERSONA_H_INCLUDED
