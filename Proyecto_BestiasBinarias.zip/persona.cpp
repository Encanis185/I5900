#include "persona.h"

Persona::Persona()
{

}

string Persona::getNombres()
{
    return Nombres;
}

string Persona::getApellido()
{
    return Apellido;
}

void Persona::setNombres(const string& n)
{
   Nombres = n;
}

void Persona::setApellido(const string& a)
{
    Apellido = a;
}


string Persona::toString()
{
    string resultado;

    resultado = Nombres;
    resultado += ",";
    resultado += Apellido;

    return resultado;
}
