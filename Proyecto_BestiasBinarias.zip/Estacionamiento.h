#ifndef ESTACIONAMIENTO_H_INCLUDED
#define ESTACIONAMIENTO_H_INCLUDED
#include <string>

using namespace std;

class Estacinamiento{
private:
    string HoraEntrada;
    string HoraSalida;
    string ModeloAuto;
    string Placa;
    int NoEstacionamiento;
public:
    void setHoraEntrada(const string&);
    void setHoraSalida(const string&);
    void setModeloAuto(const string&);
    void setPlaca(const string&);
    void setId(const int&);

    string  getHoraEntrada();
    string  getHoraSalida();
    string  getModeloAuto();
    string     getPlaca();
    int     getId();

    string imprimir();

    Estacinamiento& operator =(const Estacinamiento&);

};



#endif // ESTACIONAMIENTO_H_INCLUDED
